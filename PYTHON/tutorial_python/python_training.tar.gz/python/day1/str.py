name = raw_input("enter str:")
x = int(name) - 10
print x
print type(x)
