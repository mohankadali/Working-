#print 'hello_world
#10 = x
x = 10 / 0
