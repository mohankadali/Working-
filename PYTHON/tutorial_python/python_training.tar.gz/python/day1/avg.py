count = 5
res = 0
while count > 0:
	num = input()
	res += num 
	count -= 1
print res/5
