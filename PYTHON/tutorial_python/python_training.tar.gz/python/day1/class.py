str = "global edge"
print str[0]
#str[0] = 'j'
print str[20] 
