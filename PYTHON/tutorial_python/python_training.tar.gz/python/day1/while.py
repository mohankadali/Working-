count = 0
while (count < 9):
	print 'the count is:',count
	count += 1
var = 1
while var == 1:
	num = raw_input("enter the number:")
	print "you entered: ",num
