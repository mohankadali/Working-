num = 10
while num > 0:
	if num == 6:
		num -= 1
		continue
	print num
	num -= 1

