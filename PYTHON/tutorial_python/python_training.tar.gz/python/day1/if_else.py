
str = raw_input(str)
if str == 'saturday':
	print 'go to movie'
else :
	if str == 'sunday':
		print 'Take rest'
	else:
		 print 'Weekday'
