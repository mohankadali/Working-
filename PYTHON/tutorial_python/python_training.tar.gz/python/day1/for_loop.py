num = {1,2,3,4,5}
sum = 0
for number in numbers:
    sum = sum + numbers
print sum
