x = input()
print x
print type(x)
l = long(x)
print l
print type(l)
f = float(x)	
print f
print type(f)
c = complex(x)	
print c
print type(c)
num = complex(1, 2)
print complex(1, 2)	
print type(complex(1, 2))
