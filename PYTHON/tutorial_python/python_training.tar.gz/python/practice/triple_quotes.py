st ="""hello \t world \nwelcome"""
print st

# raw string don't care about raw string 
print 'C:\\nowhere'
# raw string don't care about raw string but if put r in front string itwill remove escape sequence it will give entire strig it will alspo consider one charater in string 
print r'C:\\nowhere'
