print "Enter var value : "
var = input()
if(var == 100) : 
	print "Value Of expression is", var
print "Good bye..... !!"				 

