# we can use '%' format specifier in C same way in python see below example 
print "My name is %s and weight is %d kg!" %('Zara', 21)
print "My name is %s and weight is %d kg!" ,('Zara', 21)
print "My name is %s " % 'Zara'

