#syntax for lambda  :- lambda arguments : expression

sqr = lambda x : x ** 3
print sqr
print type(sqr)
print sqr(5)
print sqr(6)
sqr = lambda x : x + 1

print sqr
print type(sqr)
print sqr(5)
print sqr(6)


