def change(one, *two):
	print(type(two))
	print(two)
change(1,2,3,4)
