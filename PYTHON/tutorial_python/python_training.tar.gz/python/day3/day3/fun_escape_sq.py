print r"\nhello"
print "\nhello\n"

