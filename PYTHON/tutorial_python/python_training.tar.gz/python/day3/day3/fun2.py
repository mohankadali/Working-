i = 0
def change(i):
	i = i+1
	return i
change(1)
print(i)
