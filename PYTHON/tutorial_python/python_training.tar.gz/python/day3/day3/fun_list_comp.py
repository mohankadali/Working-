# list comprehention function example

list1 = [x ** 2 for x in range(10)] #in range second parameter is optional in these is example it will take from 0 to 9
print list1   # output is 0 to 9 square values in list


