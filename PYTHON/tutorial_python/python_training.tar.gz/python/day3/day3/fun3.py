def fun1(a, **b):
	print(type(b))
fun1('lettera',A='1',B='2')

