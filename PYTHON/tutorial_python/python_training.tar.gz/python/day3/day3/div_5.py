list1 = [x for x in range(10) if x % 5 == 0]
print list1
