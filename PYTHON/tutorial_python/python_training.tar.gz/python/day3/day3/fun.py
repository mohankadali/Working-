x = 50
def func(x) :
	print('x is ', x)
	x = 2
	print('x is ', x)
func(x)
print('x is ', x)
