import os
sys.path.append("/usr/lib/python2.7")
import fun

