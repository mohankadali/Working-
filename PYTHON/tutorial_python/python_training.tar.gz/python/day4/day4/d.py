import pdb
str1="welcome yuvaraju to python class"
print str1
print str1[0:8]
print str1[8:16]
print str1[17:19]
print str1[20:26]
print str1[27:32]
def fun(name):
	print name
	name = "raju"
	return name
print fun("yuva")
