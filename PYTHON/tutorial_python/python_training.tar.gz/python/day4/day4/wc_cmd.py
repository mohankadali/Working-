fil_op = open("data.txt", "r")
print "word count : ", fil_op.count(' ')
