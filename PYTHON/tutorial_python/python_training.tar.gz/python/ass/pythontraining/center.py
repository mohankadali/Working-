string=""
string.center(30,'#')
string="calculator"
string.center(20,'#')

