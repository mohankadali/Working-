#To check whether a entered number is >100,<100 or =100

num=input("Enter a number:")

if num==100:
	print "Entered number is equal than 100"
elif num<100:
	print "Entered number is less than 100"
else:
	print "Entered number is greater than 100"
