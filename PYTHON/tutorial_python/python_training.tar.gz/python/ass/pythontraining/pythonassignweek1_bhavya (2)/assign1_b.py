#Program to print builtins

print dir(__builtins__) #Prints all builtins
