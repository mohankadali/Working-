#To print pi value and sin 90 degress value

import math

print "PI value : ",math.pi #prints pi value
print "Sin 90 degrees : ",math.sin(math.radians(90)) #prints sin value
