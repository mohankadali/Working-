#Create empty list

list1=[]
print list1

#List with 1 element

#list1[0]=1 #Not possible
list1.append(1)
print list1

#Create empty tuple

tuple1=()
#tuple1[0]=1 #Not possible

#create empty dictionary
dict1={}
print dict1

#dictionary with one pair
dict1['key']='value'
print dict1
