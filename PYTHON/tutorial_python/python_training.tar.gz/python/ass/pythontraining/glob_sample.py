import glob

print glob.glob("*.py")
