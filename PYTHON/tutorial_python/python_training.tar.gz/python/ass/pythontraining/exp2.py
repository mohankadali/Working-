#To print numbers from 1 to 10

"""num=1

while num<11:
	print num
	num+=1
"""


"""num=1
while num<11:
	if num>5:
		break
	print num
	num+=1
"""

num=1
while num<11:
	if num==5:
		num+=1
		continue
	print num
	num+=1

