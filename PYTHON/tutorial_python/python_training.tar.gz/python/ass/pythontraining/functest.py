

def test1(a,b):
	print a,b

test1(a=10,b)
