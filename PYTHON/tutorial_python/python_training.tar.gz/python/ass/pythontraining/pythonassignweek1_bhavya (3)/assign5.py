print help(range) #prints range() document

print help(cmp) #prints cmp() document
