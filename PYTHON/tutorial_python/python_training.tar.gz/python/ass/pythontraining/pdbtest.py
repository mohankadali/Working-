import pdb

a="aaa"
print a
pdb.set_trace()
b="bbb"
print b
c=a+b
print c

