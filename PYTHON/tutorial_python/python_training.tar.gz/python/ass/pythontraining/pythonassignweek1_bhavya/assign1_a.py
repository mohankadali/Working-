#To print keywords

print help("keywords") #Prints keywords

