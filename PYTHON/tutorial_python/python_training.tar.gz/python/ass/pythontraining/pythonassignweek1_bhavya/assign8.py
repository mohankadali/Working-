import os

os.chdir("../") #Changes to parent directory
