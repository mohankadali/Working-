#To work with command line arguments

import sys

print "file name:",sys.argv[0] #prints file name
print "sum:",int(sys.argv[1])+int(sys.argv[2]) #sum of 2 numbers
