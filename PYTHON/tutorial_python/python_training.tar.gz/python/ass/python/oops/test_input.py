#!/usr/bin/python
"""
	Script : test_input.py
	Author : Bhavya
	Date : April-21-2017
	Purpose :To test the Input module
"""
import Input

print Input.getinteger("Enter integer:")
print Input.getfloat("Enter float:")
print Input.getstring("Enter string:")
print Input.getchar("Enter char:")
print Input.getyesno("Enter yes or no:")
print Input.getmultistr("Enter multistring:")
