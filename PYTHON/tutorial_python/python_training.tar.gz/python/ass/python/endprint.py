#!/usr/bin/python
"""
	Script :endprint.py (works in python 3)
	Author : Bhavya
	Date : Sept-06-2017
	Purpose :To demonstrate end parameter of print statement
"""

print "hi" #prints hi and goes to new line because end param has newline character

print "hello",end='' #does not goes to new line since end is empty
