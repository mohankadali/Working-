#!/usr/bin/python

"""
	Script:celtofar.py
	Author:Bhavya
	Date: Apr-14-2017
	Purpose: celsium to Fareinheit conversion python program
"""

celsius = float(raw_input("enter celsius:"))

far = (5/9)*celsius+32

print "fareinheit:%i"%(far)
