#!/usr/bin/python
"""
	Script : custfunc.py
	Author : Bhavya
	Date : April-21-2017
	Purpose :Some of the custom-functions(UDFs)
"""

def divide(n,d):
	"""
		Return the quotient of n/d
	"""
	return n/d

def charAt(string,inx):
	"""
		Return the character from the string at the specified index.
	"""
	return string[inx]


