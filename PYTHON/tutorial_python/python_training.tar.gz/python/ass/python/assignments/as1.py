#!/usr/bin/python

"""
	Script : as1.py
	Author : Bhavya
	Date : April-20-2017
	Purpose : Using the python interpreter as a calculator and typing
				expressions
"""
print 12/(4+1)
print (12)/4+1
print 12*25/7
print 
