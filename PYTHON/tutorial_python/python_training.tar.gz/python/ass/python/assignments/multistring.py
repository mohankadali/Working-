#!usr/bin/python

"""
	Script: multistring.py
	Author : Bhavya
	Purpose : MultiString format

"""

print "enter data"

data=""
while True:
	string=raw_input()
	if string in q:
		print string
	else:
		data=string_data
