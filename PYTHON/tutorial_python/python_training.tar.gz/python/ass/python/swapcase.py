#!/usr/bin/python
"""
	Script : Swapcase
	Author : Bhavya
	Date : JUNE-12-2017
	Purpose : To swapcases
"""

def swap_case(s):
	return s.swapcase()


string=raw_input("enter string")
print swap_case(string)
