#!/usr/bin/python

"""
	Script : angle.py
	Author : Bhavya
	Date : April-14-2017
	Purpose : area of right angled triangle python program.
"""

base = int(raw_input('enter base:'))
height = int(raw_input('enter height:'))

area = float(0.5*(base*height))

print "area of %i and %i is %i"%(base,height,area)


