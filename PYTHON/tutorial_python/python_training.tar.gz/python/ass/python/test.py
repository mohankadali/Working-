#!/usr/bin/python
"""
	Script : test.py
	Author : Bhavya
	Date : April-24-2017
	Purpose : Test question
"""
i=5

def func(var=i):
	print var

i=25
func()
