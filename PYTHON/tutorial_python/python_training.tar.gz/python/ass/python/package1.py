#!/usr/bin/python

"""
	Script : package1.py
	Author : Bhavya
	Date : April-14-2017
	Purpose : First python program.
"""
import module1
import os
