#!/usr/bin/python
"""
	Script : arg.py
	Author : Bhavya
	Date : Sept-04-2017
	Purpose :Command line arguments
"""

import sys

for i in range(0,len(sys.argv)):
	print i
	print sys.argv[i]
