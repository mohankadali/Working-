#!/usr/bin/python

"""
	Script : swap.py
	Author : Bhavya
	Date : April-19-2017
	Purpose : Swap two numbers python program.
"""

number1=int(raw_input("enter first number"))
number2=int(raw_input("enter second number"))

number1,number2=number2,number1

print number1
print number2
