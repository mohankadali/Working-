#!/usr/bin/python

"""
	Script : first.py
	Author : Bhavya
	Date : April-14-2017
	Purpose : First python program.
"""
