def fun(x, y):
    print x
    print y
    return x * y
print fun(10, 20)
