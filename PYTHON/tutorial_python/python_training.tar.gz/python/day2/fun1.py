#we can keep parameters as default also.
#if we can pass default values to default parameters it will take otherwise its takes default values only
def printinfo(name, age=35):
    print "Name : ", name
    print "Age : ", age
    return;
printinfo("yuva")

