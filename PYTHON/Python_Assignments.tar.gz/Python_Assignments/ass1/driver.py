import r2

number = input("Enter number\n")
r2.isprime(number)

number = raw_input("Enter number to chech whether it is armstrong\n")
r2.armstrong(number)

ip_addr = raw_input("Enter ip address\n")
r2.isipaddr(ip_addr)

year = input("Enter a year\n")
r2.isleap(year)

date = raw_input("Enter a date\n")
r2.isdate(date)
