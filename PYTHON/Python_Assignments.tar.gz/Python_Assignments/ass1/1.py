inputstr = "My String"
inputstr
print inputstr

concatstr = inputstr+" "+inputstr   #Concatenating
mulstr = '  '.join([inputstr] * 3) #Multiplying

print concatstr
print mulstr
