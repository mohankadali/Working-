string = raw_input("Enter a string\n")

print string.islower()
print string.isupper()
print not string.islower()
