dict1 = {}
while(1):
    print "1.Add\t2.Pop\t3.Display\t4.Quit"
    inp = input("Enter operation to be done\n")
    if inp == 1:
        print "Enter key and value to be enterd\n"

