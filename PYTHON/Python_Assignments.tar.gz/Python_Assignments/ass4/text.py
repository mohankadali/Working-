harijka is a good
swetha bad girl
rajji is tot
venkat is head
hyd is metropolitan city
Goa is pink city
Cubical has 4 cubes
head command in linux
tail command in linux
nl command in linux
Implement calc in python
inputs a file1
file1 contains output
