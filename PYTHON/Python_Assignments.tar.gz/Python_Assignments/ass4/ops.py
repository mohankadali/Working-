import math

def add(num1,num2):
    print "Sum is :\t", num1 + num2
def sub(num1,num2):
    print "sub is :\t",num1 - num2
def mul(num1,num2):
    print "Mul is :\t",num1 * num2
def div(num1,num2):
    print "Div is :\t",num1/num2
def sine(num):
    print "sine :\t",math.sin(num)
def cosine(num):
    print "cos :\t",math.cos(num)
def powerof(num,power):
    print "power :\t",math.pow(num,power)
def squareroot(num):
    print "square root :\t",math.sqrt(num)
 
