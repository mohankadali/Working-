#Print modules

print help("modules") #Prints all modules
