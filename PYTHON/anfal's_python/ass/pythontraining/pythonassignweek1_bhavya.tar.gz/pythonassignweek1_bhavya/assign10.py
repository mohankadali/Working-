#Program to print version of python


import sys

print "version of python:",sys.version[0:5] #prints python version
