#All representations of a number

num=input("Enter number:") #Taking input from user

print "Decimal form: ",num #decimal representation
print "Binary representation: ",bin(num) #Binary representation
print "Hex representation: ",hex(num) #Hexadecimal representation
print "Octal representation: ",oct(num) #Octal representation
