command- getconf LONG_BIT
