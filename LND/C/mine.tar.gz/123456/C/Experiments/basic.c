#include<stdio.h> 
main()
{
int a=10,b=20,sum;
sum=a+b;
printf("sum=%d\n",sum);
}
