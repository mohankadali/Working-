#include<stdio.h>
int add(int a,int b)
{
    return a+b;
}
main()
{
    int x=10,y=20,result;
    result=add(x,y);
    printf("result=%d   \n",result);
} 

