#include<stdio.h> 
int gvar=10;
int gvar=10;
main()
{
printf("gvar=%d\n",gvar);
}
