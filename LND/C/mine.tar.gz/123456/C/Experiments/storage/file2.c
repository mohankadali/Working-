#include<stdio.h> 
main()
{
const x;   
printf("%d   %d ",x+1,x-1);



}
