extern gvar =20;
