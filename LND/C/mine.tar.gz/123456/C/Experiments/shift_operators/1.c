#include<stdio.h> 
main()
{
signed char a=-12;
unsigned char b=12;
printf("%d  ",a<<4);
printf("%d  ",a>>4);
printf("%d  ",b<<4);
printf("%d  ",b>>4);

}
