#include<stdio.h> 
#include <stdbool.h>
main()
{
    float pi=3.14;
enum bool={jan,fib};
    unsigned int a=10u;
//    unsigned int a=10l;
 //   unsigned int a=10f;
    printf("%d  \n",a);
    printf("%d  ",sizeof(signed));
    printf("float=%d  ",sizeof(float));
    printf("3.14=%d  ",sizeof(3.14));
    printf("3.14f=%d  ",sizeof(3.14f));
    printf("pi=%d  ",sizeof(pi));
    printf("sizeof bool=%d  ",sizeof(bool));
    printf("sizeof bool=%d  ",sizeof(enum bool));
}
