#include<stdio.h> 
extern int z;
//const int x=10;
//static int file_static;
main()
{
//const auto y=20;
//auto a_var;
//a_var=x;
//file_static = x;
//y=x;
//printf("%d\n",y);
printf("%d\n",z);
}
int z=50;
