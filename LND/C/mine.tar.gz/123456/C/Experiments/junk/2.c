#include<stdio.h> 
main()
{
int x=0xabcdefabcdefabcdefabcdef;
printf("%d ",sizeof(4.5));
printf("%d ",sizeof(4.5f));
}
