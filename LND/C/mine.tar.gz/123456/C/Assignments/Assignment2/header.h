#include<stdio.h>
#include<string.h> 
#define MAX 100
//#define MAX1 10
//#define MAX2 3

//Q1
void strcp ( char* , char* ) ; 

//Q2
void strncp ( char* , char* , int ) ; 

//Q3

char *chr_add_instr ( char* , char ) ;

//Q4

char * sappend ( char* , char* ) ; 

//Q5

char * snappend ( char * , char * , int ) ;

//Q6

char strcm (char *, char * );

//Q7

char strcasecm (char * , char * );

//Q8

int size_tstrspn ( const char * , const char * );

//Q9

char *strtokk( char *, char *);

//Q10

int palindrome(char*);

//Q11

char* reverse(char*);

//Q12

char* squeezed(char*);

//Q13

int strrot(char *, char *);

//Q14

char *remsstr(char *, char *);

//Q15

char * insertchar (char *, const char , int );

//#include<stdlib.h> 
