char* reverse(char* str)    //called function
{
    int  i , j,temp;   
    for(i=0;str[i];i++);

    for(j=0,i=i-1;i>j;i--,j++)          //reversing the string
    {
        temp=str[i];
        str[i]=str[j];
        str[j]=temp;
    }
    return str; 
}
