int  q1_a();
int  q1_b();
int  q1_c();
void q2();
void q3();
