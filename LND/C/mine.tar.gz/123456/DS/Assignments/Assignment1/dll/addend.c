#include "header.h"

extern node *head;

int add_end (int ele)
{
	node *nu, *temp;
	
	nu = (node*)malloc(sizeof(node));
		if(head == NULL) {

		head = nu;
		nu->data = ele;
		head->next = NULL;
		head->prev = NULL;
		}
	else {
			temp = head;
			while (temp->next != 0) {
				temp = temp->next;
			}
			nu->next = temp->next;
			nu->data = ele;
			nu->prev = temp;
			temp->next = nu;

		}
}
