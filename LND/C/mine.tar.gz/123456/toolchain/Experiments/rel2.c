int A,B,C;                  //.bss
char w = 'A';               //.data
int ex=10;                  //.data
void add(int a,int b)
{
    A=89889;                   //stack
    printf("in add fun A=%d\n",A);
    return ;
}
