#include <stdio.h>
#include <elf.h>
#include <stdbool.h>
#include <inttypes.h>
#include <stdlib.h>

#define MAXBYTES 52
#define UNVALID 0
#define SIZE 100
#define SET 1
#define UNSET 0
#define SPACE 40 
#define MAGIC 16
/*
struct ELF_Header
{
 unsigned char e_ident[SIZE];
 short e_type;
 short e_machine;
 int e_version;
 int e_entry;
 int e_phoff;
 int e_shoff;
 int e_flags;
 short e_ehsize;
 short e_phentsize;
 short e_phnum;
 short e_shentsize;
 short e_shnum;
 short e_shstrndx;

};*/
