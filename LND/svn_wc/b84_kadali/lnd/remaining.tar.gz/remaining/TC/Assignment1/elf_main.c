#include "header.h"

int main ( int argc, char *argv[] )
{

		char *name = argv[1];
		FILE *f_ptr ;
		
		printf("name:%s", name);
		elf_header ( name );

return 0;
}
