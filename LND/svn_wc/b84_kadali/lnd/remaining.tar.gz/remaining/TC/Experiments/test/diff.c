#include"header.h"
int diff(int a,int b)
{
    return (a-b);
}
