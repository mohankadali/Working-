#include <stdio.h> 
#include <unistd.h>
int main()
{
    printf ("hello\n");
    execlp ("ls","pwd", NULL);
    printf ("hello\n");
    while(1);
    return 0;
}
