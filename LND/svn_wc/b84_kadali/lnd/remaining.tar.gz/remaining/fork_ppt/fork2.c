#include <stdio.h> 
int main ()
{
    while(1)            //creating infinite child processes 
    {
        fork ();
    }
    return 0;
}
