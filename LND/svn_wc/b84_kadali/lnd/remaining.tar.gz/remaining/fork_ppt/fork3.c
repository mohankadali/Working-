#include <stdio.h>
int i=10;
int main()
{
int x=20;
    printf("I am not a part of child process... check which process is executed first parent (or) childs?\n");
    fork ();
    fork ();
    fork ();
    printf ("helloi= %d %d\n",i,x); 
    return 0;
}
