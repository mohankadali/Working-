#include<stdio.h> 
#include<stdlib.h>
int main()
{
    printf("hello");
    _Exit(0);
    printf("ello");
    return 0;
}          
