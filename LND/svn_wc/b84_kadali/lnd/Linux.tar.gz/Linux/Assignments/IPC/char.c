#include <stdio.h>

int main ()
{
    char ch[4];
    int *ptr; 
    ptr = &ch ;
    printf (" %d ",*ptr) ;
    return 0 ;
}
