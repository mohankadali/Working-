//function prototype

asmlinkage long  sys_my_syscall(void);
