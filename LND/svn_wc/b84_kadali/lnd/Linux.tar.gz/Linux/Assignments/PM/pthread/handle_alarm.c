
#include "mypthread.h"

int handle_alarm ( int seconds , char * msg ) 
{

   sleep ( seconds ) ;
   printf ("%d   %s\n" , seconds , msg ); 
   return 0;   
}

int handle_zombies ( void ) 
{
    return 0; 
}  
