#include <stdio.h> 
#include <stdlib.h>
int data = 10;
int main()
{

    int stack;
    stack = 20;
    int *heap = (int *)malloc (sizeof (int));
    *heap = 30;
    getchar ();
    return 0;
}
