#include"header.h"
char pop (STACK *stack)
{
        return stack -> array [(stack -> top)--];
}
