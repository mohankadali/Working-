#include <stdio.h>
#include "ds_ass1_header.h"

int main(void)
{

    int option;

    while ( 1 ) {

    printf ("\nEnter the option : \n1:Stack\n2:Linked list using Stack\n3:Queue\n4:Circular queue\n5:Singly list\n6:Doubly list\n7:Circular singly list\n8:Circular doubly list\n9:Exit\n\n");
    scanf ("%d", &option );


    switch ( option ) 
    {
        case 1:
           a1();
           break;

        case 2:
           a2();
           break;

        case 3:
           a3();
           break;

        case 4:
           a4();
           break;

        case 5:
           a5();
           break;

        case 6:
           a6();
           break;

         case 7:
           a7();
           break;

         case 8:
           a8();
           break;


        case 9:
           exit (0);
           break;

        default:
          printf ("\nEnter a valid option \n");
          break; 

               

    }
    }
    return 0;
}
