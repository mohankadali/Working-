
#include <stdio.h>
#include "ds_ass1_header.h"

void pop ( int *top )
{
    printf ("\ntop : %d \n", *top );

    if ( MAX == *top ) {

        printf ("\n<--------------stack is empty---------------> \n");
        return ;
    }

    stack [ ( *top ) ++ ] = 0;
    printf ("\nElement is popped \n");
}































