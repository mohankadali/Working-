
#include <stdio.h>
#include "ds_ass1_header.h"

void display ( void )
{
    int iter;

    printf ("\nElements in stack are :  \n\n");

    for ( iter = 0; iter < MAX; iter++ ) {

        printf ("%d  ", stack [ iter ] );

    }
    printf ("\n");
}
































