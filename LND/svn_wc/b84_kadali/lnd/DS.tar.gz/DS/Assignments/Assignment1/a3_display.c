
#include <stdio.h>
#include "ds_ass1_header.h"

void display_q ( int *front, int *rear )
{
    int iter;

    printf ("\nElements in queue are :  \n\n");

    for ( iter = *front ; iter < *rear; iter++ ) {

        printf ("%d  ", q [ iter ] );

    }
    printf ("\n");
}
































