
#include <stdio.h>
#include "ds_ass1_header.h"


void push ( int ele, int *top )
{

    if ( *top <= 0 ) {
        printf ("\n<---------------Stack is full----------------> \n");
        return ;
    }

    printf ("\nAddress of the element is : %p \n", &stack [ ( *top ) - 1 ] );

    stack [ -- ( *top ) ] = ele;

    printf ("\nElement is pushed to the stack \n");
    return ;
}































