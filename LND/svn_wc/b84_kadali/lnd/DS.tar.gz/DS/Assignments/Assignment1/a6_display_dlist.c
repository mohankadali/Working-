
#include <stdio.h>
#include "ds_ass1_header.h"
/*
void display_slist ( slist *head )
{
    //pointer is made to point to the head node
    slist *ptr = head ;

    printf ("\nElements in the linked list are :  \n\n");

    //loop till the end of the node
    while ( ptr != NULL ) {

        printf ("%d  ", ptr->data );
        //to make the pointer to point to the next node
        ptr = ptr->next;

    }

    printf ("\n");
}
*/


void display_dlist ( dlist *head )
{
    //pointer is made to point to the head node
    dlist *ptr = head ;

    printf ("\nElements in the linked list are :  \n\n");

    //loop till the end of the node
    while ( ptr != NULL ) {

        printf ("%d  ", ptr->data );
        //to make the pointer to point to the next node
        ptr = ptr->next;

    }

    printf ("\n");
}































