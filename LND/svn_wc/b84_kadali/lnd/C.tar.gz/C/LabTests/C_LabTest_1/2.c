#include<stdio.h> 
#define MAX 100
main()
{
    int sum=0,i;
    char str[MAX];
    printf("enter the string....\n");
    scanf("%s",str);
    for(i=0;str[i];i++)
        sum=sum+str[i];
    printf("sum of ASCII=%d\n",sum);
}
