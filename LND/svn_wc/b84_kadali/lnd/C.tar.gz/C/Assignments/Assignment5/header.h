#include<string.h> 
void question1(void);
void question2(void);
void question3(void);
void question4(void);
void question5(void);
void question6(void);
