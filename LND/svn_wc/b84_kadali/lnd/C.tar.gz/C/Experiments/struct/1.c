#include<stdio.h> 
struct s
{

}A;
main()
{
    printf("size=%d\n",sizeof(A));
}

