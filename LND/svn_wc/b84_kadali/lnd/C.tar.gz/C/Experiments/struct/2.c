#include<stdio.h> 
struct s
{
};

int main(  )
{
    struct s ST;
    //struct st 
    printf("%d\n",sizeof(ST));
}
