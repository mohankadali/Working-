#include<stdio.h> 
main()
{
int x;
printf("%d %d  ",x);


}
int y=10;
