#include<stdio.h> 
int z=20;
main()
{
    printf("%p\n",&z);
while(1);
}
