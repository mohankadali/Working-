#include<stdio.h> 
int x=10;
int y=x;
main()
{
int z;
    printf("%d\n",y);
}
