#include<string.h>
#include<stdlib.h>
#include<stdio.h> 
main()
{
// char str1[1][20]="helloworld";
//char str2[2][20]={"helloworld"};
//char str3[1][20]={"hello","world"};
char str4[][20]={"hello world"};
//printf("%s  \n",str1[0]);
//printf("%s  \n",str2[0]);
printf("%s  \n",str4[0]);
//printf("%s  \n",str4);
}
