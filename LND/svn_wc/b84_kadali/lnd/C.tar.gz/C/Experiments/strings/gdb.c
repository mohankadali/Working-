#include<stdio.h> 
int add(int a,int b)
{
    return a+b;
}
int main()
{
    int n1,n2,result;
    printf("enter two number...\n");
    scanf("%d%d",&n1,&n2);
    result=add(n1,n2);
    printf("output=%d\n",result);
    return 0;
}
