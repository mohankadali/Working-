#ifndef _ADD_H
#define _ADD_H
int add(int,int);
#endif
