#include"add.h"
#include<stdio.h> 
int main()
{
    int n1,n2;
    printf("enter the numbers....\n");
    scanf("%d%d",&n1,&n2);
    printf("sum=%d\n",add(n1,n2));
    return 0;
}
