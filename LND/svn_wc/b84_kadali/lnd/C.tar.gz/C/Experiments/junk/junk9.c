
#include<stdio.h> 
main()
{
    int a =4,b=5;
  //  int c;
  //  int quot = a/b ;
  //  int rem = (a -(quot *b)) ;
    printf("printf("hello")");

}
