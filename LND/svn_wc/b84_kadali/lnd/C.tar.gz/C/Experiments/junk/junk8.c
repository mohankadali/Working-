#include<stdio.h> 
void main()
{
    int i=0;
    int array[5];
    for(i=0;i<=5;i++)
        array[i]=0;
    printf("hii  ii...");
}
