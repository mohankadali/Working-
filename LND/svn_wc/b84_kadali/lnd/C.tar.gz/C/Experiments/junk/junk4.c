#include<stdio.h> 

int main ()
{
    int i,j,k;
    int  ***p = (int ***) malloc (2 * sizeof (int **));
    for(i = 0; i < 2; i ++)
    {
        p[i] = (int **) malloc (2 * sizeof(int *));
        for(j= 0; j<2;j++) 
        {
            p[i][j] = (int )malloc(3 * sizeof(int));
        }
    }
    for(i =0 ;i<2 ;i++)
    {
        for(j =0 ;j<2 ;j++)
        {    
            for(k = 0 ;k < 2; k ++)
            {
                p[0][0][0] = 98;
            }
        }    
    }
    printf("%d\n",p[0][0][0]);
}
