#include<stdio.h> 
struct str {
    int a;
    char b;
//    char c[ ];
} s;
/*
struct str {
    int a;
    char b;
};
*/
main ()
{
//    struct str *s;
printf("%d\n",sizeof(s));
}

