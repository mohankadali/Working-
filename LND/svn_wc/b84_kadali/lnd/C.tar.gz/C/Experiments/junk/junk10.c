#include<stdio.h> 
main()
{
int num;
num = printf("%z");
printf("%d \n",num);
}
