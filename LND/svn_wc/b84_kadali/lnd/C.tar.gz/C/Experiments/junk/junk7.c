#include<stdio.h> 
int q = 10;
main()
{
int q = q;
printf("%d\n",q);

}
