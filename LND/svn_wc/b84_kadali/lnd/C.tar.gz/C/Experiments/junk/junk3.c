#include <stdio.h> 
#include <stdlib.h>

int b = 10;
int c = 20;
int d;
int e;
const int f = 10;
const int g = 90;
const int h = 789;
const int i = 543;

int main ()
{

int *p = malloc(10) ;
*p =20;
free(p);

*(p+1) = 30;
//*(p+0) = *(p+1); 

    int b = 30;
    printf ("%d\n", *p);
//    int *p = malloc (10);
}
