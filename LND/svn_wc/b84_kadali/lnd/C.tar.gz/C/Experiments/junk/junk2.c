#include<stdio.h> 
int main ()
{

int *p = 0x08048000;
printf("%d\n",*p);
}
