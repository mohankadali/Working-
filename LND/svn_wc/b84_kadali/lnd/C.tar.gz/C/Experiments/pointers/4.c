#include<stdio.h> 
main()
{

printf("%d   ",*(int *)v);
}
        
