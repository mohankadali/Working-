#include<stdio.h> 
main()
{
    int x=10;
    int *p;
    p=&x;
    printf("p=%p   \n",p);
    printf("&x=%p   \n",&x);
    printf("x=%d   \n",x);
    printf("*p=%d  \n",*p);

}
