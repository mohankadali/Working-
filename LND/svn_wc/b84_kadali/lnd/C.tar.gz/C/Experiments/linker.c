#include<stdio.h> 
int x=10;
main()
{
    printf("%p\n",&x);
while(1);
}
