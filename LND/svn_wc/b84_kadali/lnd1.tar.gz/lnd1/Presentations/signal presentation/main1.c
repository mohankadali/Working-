#include<stdio.h> 
main()
{
    printf("hi");
main();

}
