
#include <stdio.h>

//Declaring a structure

struct st {

    int a ;
    int b ;
    char c ;
    char d ;
    char e ;
    char f ;
    char g ;
    char h;
    short i; 
};

int main (void)
{
    struct st *ptr = NULL ;

    ptr++ ;//Incrementing pointer

    printf ("%d\n", ptr) ;

    return 0 ;
}
