
//union example

#include <stdio.h>

//union declaration

union u {
    int a ;
    char c ;
    int b ;
} ;

int main (void)
{
    //initializing members
    union u var = { 1, 'c', 3.2} ; 

    //assigning members
/*    var.a = 10 ;
    var.c = 'b' ;
    var.b = 5 ;
*/
    printf ("%d  %d  %d\n", var.a, var.c, var.b ) ;
    return 0 ;
}
