//bitfields usage

#include <stdio.h>

//declaring a structure
struct st {
    int a:6 ;
    int  :0 ;//dummy bitfield
    char c:3 ;
} ;

int main (void)
{
    //printing size of structure
    printf ("size:%d\n", sizeof ( struct st ) ) ;

    return 0 ;
}
