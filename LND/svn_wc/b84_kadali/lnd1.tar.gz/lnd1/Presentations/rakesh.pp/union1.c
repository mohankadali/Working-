
//union example

#include <stdio.h>

//union declaration

union u {
    int a ;
    char c ;
    int b ;
} ;

int main (void)
{
    //initializing members
    union u var[3] = { 10, 20, 30} ; 
    /*    union u var;
          var.a = 10;
          var.c = 890;
          var.b = 90;
          */
    printf ("%d  %d  %d\n", var[0].a, var[1].c, var[2].b ) ;

    return 0 ;
}
