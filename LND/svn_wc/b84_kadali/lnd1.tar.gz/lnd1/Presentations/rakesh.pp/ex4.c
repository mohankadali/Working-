#include <stdio.h>

// Alignment example

// structure A
struct a_tag {    
     char c ;
     short int s ;
} ;

// structure B
struct b_tag {
     short int  s;
     char c;
     int i;
} ;

// structure C
struct c_tag {
     char c;
     double d;
     int s;
} ;

// structure D
struct d_tag {
     double d;
     int s;
     char c;
} ;

int main ()
{
     //printing size of structures

     printf ("%d\n", sizeof(struct a_tag));
     printf ("%d\n", sizeof(struct b_tag));
     printf ("%d\n", sizeof(struct c_tag));
     printf ("%d\n", sizeof(struct d_tag));

     return 0 ;

}
